<footer class="bg-light text-center text-lg-start mt-auto">
  <div class="text-center p-3">
    © 2021 Copyright:
    <a class="text-dark" href="https://openclassrooms.com/">OpenClassrooms</a>
  </div>
  <?php include_once('viewed_pages.php'); ?>
</footer>
